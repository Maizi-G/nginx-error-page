// Package appmeta provides the application metadata, such as version.
package appmeta
